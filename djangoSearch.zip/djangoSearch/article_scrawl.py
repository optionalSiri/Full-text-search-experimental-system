'''
爬取博客园某个作者所有文章
'''
from bs4 import BeautifulSoup
import requests
import pymysql

# 895条
class ArticleScrawl(object):
    def __init__(self):
        self.conn = pymysql.connect(host='localhost',
                               user='root',
                               password='125225',
                               db='dj_search',
                               charset='utf8')
        self.cursor = self.conn.cursor()

    def get_bs(self, author, page=1):
        r = requests.get(f'https://www.cnblogs.com/{author}/default.html?page={page}')
        soup = BeautifulSoup(r.content, 'html5lib')
        print(f'第{page}页：')
        self.data_print(soup)
        if soup.select(f'a[href="https://www.cnblogs.com/{author}/default.html?page={page + 1}"]'):
            self.get_bs(author, page + 1)

    def data_print(self, soup):
        for day in soup.select('div.day'):
            for riqi in day.select('div.dayTitle a'):
                for wenzhang in day.select('a.postTitle2'):
                    title = str(wenzhang.text).strip()
                    abstract = str(day.select('div.c_b_p_desc')[0].text).strip()
                    release_time = str(riqi.text).strip()
                    detail_href = str(day.select('a.vertical-middle')[0].get('href')).strip()
                    item = {"title": title, "abstract": abstract, "release_time": release_time, "detail_href": detail_href}
                    print(item)
                    self.save_data(item)

    def save_data(self, item):
        sql = "insert into search_article(title, abstract, release_time, detail_href) values(%s, %s, %s, %s)"
        self.cursor.execute(sql, [item["title"], item["abstract"], item["release_time"], item["detail_href"]])

    def __del__(self):
        self.conn.commit()
        self.cursor.close()  # 关闭游标
        self.conn.close()




if __name__ == "__main__":
    art = ArticleScrawl()
    art.get_bs('yoyoketang')
