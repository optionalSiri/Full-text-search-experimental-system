# 注意, 在app 目录下创建 documents.py 文件   名字一定要对, 不然执行命令时 会找不到索引
from django_elasticsearch_dsl import Document, fields
from django_elasticsearch_dsl.registries import registry
from djangoSearch.search.models import Article

# python ../../manage.py search_index --rebuild

@registry.register_document
class ArticleDocument(Document):
     # 自定义索引字段类型  因为要作为mysql数据库的延伸 , 所以需要自定义字段为keyword 类型. 否则会被es自动分词
    # pk = fields.IntegerField()
    # title = fields.KeywordField()
    # abstract = fields.KeywordField()
    # release_time = fields.KeywordField()
    # detail_href = fields.KeywordField()

    class Index:
        name = 'dj_search'
        settings = {
            # 设置最大索引深度(**重要)  分页查询时要用到
            'max_result_window': 10000000,
            # 切片个数
            'number_of_shards':8,
            # 保存副本数
            'number_of_replicas':2
        }

    class Django:
        model = Article  # 与此文档关联的模型
        # 要在Elasticsearch中建立索引的模型的字段
         #  fields 置空 则会根据上方的对象的属性进行映射,  可直接写orm模型类字段名, 会根据orm中的字段类型进行自动选择文档字段类型
        fields = ["id", "title", "abstract", "release_time", "detail_href"]
        # 执行迁移时的 每次从mysql中数据读取的条数.
        queryset_pagination = 50000
