from django.db import models

# Create your models here.
class Article(models.Model):

    id = models.AutoField(primary_key=True)
    title = models.CharField(verbose_name='标题', max_length=2000)
    abstract = models.CharField(verbose_name='摘要', max_length=2000)
    release_time = models.CharField(verbose_name='发布时间', max_length=2000)
    detail_href = models.CharField(verbose_name='文章详情链接', max_length=2000)

    def __str__(self):
        return self.title

    class Meta:
        db_table = "search_article"
