from django.conf.urls import url
from . import views

urlpatterns = [
    url(r'^$', views.to_home),
    url(r'^do_query/', views.do_query),
]
