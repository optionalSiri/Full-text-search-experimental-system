from django.shortcuts import render
import time
from elasticsearch import Elasticsearch
from elasticsearch_dsl import Search

# Create your views here.
# 创建相关实例
# es = Elasticsearch()
# # using参数是指定Elasticsearch实例对象，index指定索引，可以缩小范围，index接受一个列表作为多个索引，且也可以用正则表示符合某种规则的索引都可以被索引，如index=["bank", "banner", "country"]又如index=["b*"]后者可以同时索引所有以b开头的索引，search中同样可以指定具体doc-type
# s = Search(using=es, index="dj_search")

client = Elasticsearch(hosts=["127.0.0.1"])

def to_home(request):
    return render(request, 'home.html')

def do_query(request):
    if request.method == "POST":
        input_content = request.POST.get('input_content')
        print(input_content)
        response = client.search(  # 原生的elasticsearch接口的search()方法，就是搜索，可以支持原生elasticsearch语句查询
            index="dj_search",  # 设置索引名称
            # doc_type="article",  # 设置表名称
            body={  # 书写elasticsearch语句
                "query": {
                    "multi_match": {  # multi_match查询
                        "query": input_content,  # 查询关键词
                        "fields": ["title", "abstract"]  # 查询字段
                    }
                },
                "from": 0,  # 从第几条开始获取
                "size": 10,  # 获取多少条数据
                # "highlight": {  # 查询关键词高亮处理
                #     "pre_tags": ["<span class=\"keyWord\" style=\"color:red\">"],  # 高亮开始标签
                #     "post_tags": ['</font></span>'],  # 高亮结束标签
                #     "fields": {  # 高亮设置
                #         "title": {},  # 高亮字段
                #         "abstract": {}  # 高亮字段
                #     }
                # }
            }
        )
        total_nums = response["hits"]["total"]  # 获取查询结果的总条数
        hit_list = []  # 设置一个列表来储存搜索到的信息，返回给html页面
        for hit in response["hits"]["hits"]:  # 循环查询到的结果
            hit_dict = {}  # 设置一个字典来储存循环结果
            # if "title" in hit["highlight"]:  # 判断title字段，如果高亮字段有类容
            #     hit_dict["title"] = "".join(hit["highlight"]["title"])  # 获取高亮里的title
            # else:
            hit_dict["title"] = hit["_source"]["title"]  # 否则获取不是高亮里的title

            # if "abstract" in hit["highlight"]:  # 判断description字段，如果高亮字段有类容
            #     hit_dict["abstract"] = "".join(hit["highlight"]["abstract"])[:500]  # 获取高亮里的abstract
            # else:
            hit_dict["abstract"] = hit["_source"]["abstract"]  # 否则获取不是高亮里的abstract

            hit_dict["detail_href"] = hit["_source"]["detail_href"]  # 获取返回url

            hit_list.append(hit_dict)  # 将获取到内容的字典，添加到列表
        print(hit_list)
        return render(request, 'dispaly_article_list.html', {"all_hits": hit_list, "key_words": input_content, "count": total_nums})  # 显示页面和将列表和搜索词返回到html
    else:
        print("....")
    return render(request, 'dispaly_article_list.html', {"data": [1, 2, 3, 4, 5]})

